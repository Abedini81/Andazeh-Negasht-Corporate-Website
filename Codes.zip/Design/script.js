let currentIndex = 0;
const slides = document.querySelectorAll('.slide');
const slideTexts = document.querySelectorAll('.slide-text');
const totalSlides = slides.length;

const slideTextContent = [
  "دقیق‌ترین ابزارهای اندازه‌گیری", 
  "متن اسلاید دوم",                  
  "متن اسلاید سوم"                    
];

function showNextSlide() {
    // Remove 'active' class from current slide and text
    slides[currentIndex].classList.remove('active');
    slideTexts[currentIndex].classList.remove('active');
    
    // Move to the next slide
    currentIndex = (currentIndex + 1) % totalSlides;
    
    // Add 'active' class to the next slide and text
    slides[currentIndex].classList.add('active');
    slideTexts[currentIndex].classList.add('active');
    
    // Update the slide text
    slideTexts[currentIndex].textContent = slideTextContent[currentIndex];
}

// Start the slideshow
setInterval(showNextSlide, 3000); // Change image and text every 3 seconds

// Handling click event for product items
document.querySelectorAll('.product-item').forEach(item => {
    item.addEventListener('click', () => {
        alert('اطلاعات بیشتری درباره ' + item.querySelector('h3').textContent);
    });
});

// Navigation slide logic (e.g., next/previous buttons)
let slideIndex = 0;
showSlides();  // Call the function to initialize the first slide

function showSlides() {
    let slides = document.getElementsByClassName("mySlides");
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    slides[slideIndex-1].style.display = "block";  
    setTimeout(showSlides, 3000); // Change slide every 3 seconds
}

function moveSlide(n) {
    slideIndex += n;
    let slides = document.getElementsByClassName("mySlides");
    if (slideIndex > slides.length) {slideIndex = 1}
    if (slideIndex < 1) {slideIndex = slides.length}
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";  
    }
    slides[slideIndex-1].style.display = "block";  
}

// کد جدید برای نمایش پیام موفقیت‌آمیز پس از ارسال فرم
document.getElementById("survey-form").addEventListener("submit", function(event) {
    event.preventDefault(); // جلوگیری از ارسال فرم و بارگذاری مجدد صفحه

    // نمایش پیام موفقیت‌آمیز
    const responseMessage = document.getElementById("response-message");
    responseMessage.style.display = "block";

    // اضافه کردن تاخیر برای پنهان کردن پیام بعد از 5 ثانیه (اختیاری)
    setTimeout(() => {
        responseMessage.style.display = "none";
    }, 5000);
});